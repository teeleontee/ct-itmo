module HW5.Parser
  ( parse
  , pHiBinOp
  , pHiNumber
  , pHiExpr
  , pHiExprList
  ) where

import Data.Void (Void)
--import Text.Megaparsec.Error (ParseErrorBundle)
import Text.Megaparsec hiding (parse)

import HW5.Base (HiExpr (..), HiFun (..), HiValue (..))
import Text.Megaparsec.Char 
import qualified Text.Megaparsec.Byte.Lexer as L
import Text.Megaparsec.Char.Lexer (scientific, skipLineComment, skipBlockComment, signed)
import Control.Monad (void)

type Parser = Parsec Void String

parse :: String -> Either (ParseErrorBundle String Void) HiExpr
parse = runParser pHiExpr "error"

pHiBinOp :: Parser HiFun
pHiBinOp = choice
  [ HiFunDiv <$ string "div" 
  , HiFunAdd <$ string "add"
  , HiFunSub <$ string "sub"
  , HiFunMul <$ string "mul"
  ]

pHiBinaryFunc :: Parser HiValue
pHiBinaryFunc = do HiValueFunction <$> pHiBinOp

sc :: Parser ()
sc = L.space
  space1
  (skipLineComment "//")
  (skipBlockComment "/*" "*/")

lexeme :: Parser a -> Parser a
lexeme = L.lexeme sc

symbol :: String -> Parser String
symbol = L.symbol sc

parens :: Parser a -> Parser a
parens = between (symbol "(") (symbol ")")

pHiNumber :: Parser HiValue
pHiNumber = lexeme $ do
  res <- toRational <$> signed sc scientific
  return $ HiValueNumber res

pHiExprList :: Parser [HiExpr]
pHiExprList = sepBy (space *> pHiExpr <* space) (char ',')

pHiExpr :: Parser HiExpr
pHiExpr = do
  first <- pHiValue
  HiExprApply (HiExprValue first) <$> parens pHiExprList <|> return (HiExprValue first)
                                   
pHiValue :: Parser HiValue
pHiValue = pHiNumber <|> pHiBinaryFunc
