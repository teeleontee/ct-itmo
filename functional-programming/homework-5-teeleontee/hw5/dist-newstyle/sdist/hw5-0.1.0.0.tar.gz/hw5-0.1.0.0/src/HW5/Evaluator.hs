module HW5.Evaluator
  ( eval
  ) where

import HW5.Base (HiError (..), HiExpr(..), HiValue(..), HiFun(..))
import Control.Monad.Except
import Control.Monad.Trans.Except

eval :: Monad m => HiExpr -> m (Either HiError HiValue)
eval expr = runExceptT $ case expr of
  HiExprValue val       -> return val
  HiExprApply func list -> do
                             hival <- ExceptT $ eval func
                             case hival of
                                      HiValueNumber _   -> throwE HiErrorInvalidFunction
                                      HiValueFunction f -> case f of
                                                             HiFunAdd -> evalBinOp (+) HiFunAdd list
                                                             HiFunSub -> evalBinOp (-) HiFunSub list
                                                             HiFunMul -> evalBinOp (*) HiFunMul list
                                                             HiFunDiv -> evalBinOp (/) HiFunDiv list

type BinOp = Rational -> Rational -> Rational 

evalBinOp :: Monad m => BinOp -> HiFun -> [HiExpr] -> ExceptT HiError m HiValue
evalBinOp _ HiFunDiv [HiExprValue (HiValueNumber _), HiExprValue (HiValueNumber 0)] = throwE HiErrorDivideByZero
evalBinOp op _ [HiExprValue (HiValueNumber lhs), HiExprValue (HiValueNumber rhs)] = returnHiValue op lhs rhs
evalBinOp op _ [lhs, HiExprValue (HiValueNumber rhs)] = do 
  val <- evalExpr' lhs
  returnHiValue op val rhs
evalBinOp op _ [HiExprValue (HiValueNumber lhs), rhs] = do
  val   <- evalExpr' rhs
  returnHiValue op lhs val
evalBinOp op _ [lhs, rhs] = do
  left  <- evalExpr' lhs
  right <- evalExpr' rhs
  returnHiValue op left right
evalBinOp _ _ _ = throwE HiErrorArityMismatch

evalExpr' :: Monad m => HiExpr -> ExceptT HiError m Rational
evalExpr' expr = do
  evaluated <- ExceptT $ eval expr
  getNumFromHiValue evaluated

getNumFromHiValue :: Monad m => HiValue -> ExceptT HiError m Rational
getNumFromHiValue (HiValueNumber val) = return val
getNumFromHiValue _ = throwE HiErrorInvalidArgument

returnHiValue :: Monad m => BinOp -> Rational -> Rational -> ExceptT HiError m HiValue
returnHiValue op lhs rhs = return $ HiValueNumber $ op lhs rhs

