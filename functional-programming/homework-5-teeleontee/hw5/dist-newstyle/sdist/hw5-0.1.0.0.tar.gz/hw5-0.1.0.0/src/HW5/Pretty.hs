module HW5.Pretty
  ( prettyValue
  ) where

import Prettyprinter
import Prettyprinter.Render.Terminal (AnsiStyle)
import Data.Ratio
import Data.Scientific

import HW5.Base (HiValue (..))

prettyValue :: HiValue -> Doc AnsiStyle
prettyValue (HiValueNumber num) = numberPrinter num
prettyValue _ = undefined

numberPrinter :: Rational -> Doc AnsiStyle
numberPrinter num = let a = numerator num
                        b = denominator num
                    in case b of
                         1 -> pretty a
                         _ -> rationalNumberPrinter num

rationalNumberPrinter :: Rational -> Doc AnsiStyle
rationalNumberPrinter a = let (x, y) = fromRationalRepetendUnlimited a
                          in case y of
                               Nothing -> finiteNumberPrinter x
                               Just _  -> infiniteNumberPrinter a

finiteNumberPrinter :: Scientific -> Doc AnsiStyle
finiteNumberPrinter a = pretty $ formatScientific Fixed Nothing a

infiniteNumberPrinter :: Rational -> Doc AnsiStyle
infiniteNumberPrinter a = let x = numerator a
                              y = denominator a
                              (w, q) = quotRem x y
                          in pretty w <+> pretty "+" <+> pretty q <> slash <> pretty y

